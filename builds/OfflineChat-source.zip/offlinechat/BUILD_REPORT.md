# Verified build

OfflineChat 0.1.0+1 was built in release mode from this source.

| Component | Version |
| --- | --- |
| Flutter | 3.35.7 |
| Dart | 3.9.2 |
| JDK | Eclipse Temurin 21.0.12.1+1 |
| Gradle | 8.12 |
| Android Gradle plugin | 8.9.1 |
| Kotlin Gradle plugin | 2.1.0 |
| Compile / target SDK | 36 |
| Minimum SDK | 24 (Android 7.0) |

Validation:

- `flutter analyze`: no issues found.
- `flutter test`: 23 passed, 0 failed, 0 skipped (11 protocol, 10 controller,
  2 widget tests).
- `flutter build apk --release`: passed.
- `apksigner verify`: passed, APK Signature Scheme v2.
- `zipalign -c -P 16 -v 4`: passed.
- APK ZIP CRCs and Flutter/app native libraries checked for `armeabi-v7a`,
  `arm64-v8a`, and `x86_64`.
- Packaged manifest checked: BLE permissions present; no INTERNET permission.

The release-mode APK uses an Android development signing key for sideload
testing. The key is not included in the source archive. App-store distribution
requires your own release signing configuration.

The original source overlay was turned into a complete Android Flutter project.
Controller fixes release native BLE resources on shutdown, guard asynchronous
callbacks after disposal, invalidate queued packets when the connection changes,
filter incoming notifications and clean up failed connections. Existing chat
features and the BLE wire format are retained.

Tests use mocked platform channels and do not establish radio compatibility.
Advertising, discovery, bidirectional messages, delivery acknowledgments and
reconnection still need the two-phone procedure in README.md.
