# OfflineChat

An Android app for a foreground, two-phone chat over Bluetooth Low Energy.
One phone hosts; the other scans and joins. Text, display names and delivery
acknowledgments travel over BLE. Nicknames and the latest 200 messages are
stored on the phone. No server or internet connection is used for chat.

## Build

Use Flutter 3.35.7, Java 17 or 21 and Android SDK platform 36. The app requires
Android 7.0 (API 24) or newer. Dependency downloads need internet access on the
development machine.

```sh
flutter pub get
flutter analyze
flutter test
flutter build apk --release
```

The APK is written to `build/app/outputs/flutter-apk/app-release.apk`.
The generated Flutter release configuration uses the development signing key
for local installation. Configure your own release signing before distributing
through an app store; keep signing keys and passwords outside the source tree.

## Try it on two phones

1. Install the APK on two physical Android phones. At least the host must
   support BLE advertising and GATT peripheral mode.
2. Enable Bluetooth and grant Nearby Devices permission. Android 11 and older
   may also need location permission and Location Services for scanning.
3. Open OfflineChat on both phones and use the pencil button to set names.
4. Tap **Host** on one phone and **Find phones** on the other. Select the host.
5. Keep both apps visible. Send text in both directions and check that each
   outgoing message changes to **delivered** after the receiver acknowledges it.
6. Test emoji and a 200-character message, then Stop and reconnect. Restart the
   app to check that local history remains available.

Wi-Fi and mobile data may be disabled during these tests. BLE transport still
requires physical-device validation; a successful build and automated tests do
not establish radio compatibility or delivery on real phones.

## Scope

This is a single-peer prototype. It has no application-layer encryption,
authenticated pairing, automatic reconnect, background delivery, retry protocol
or per-contact histories. Local preferences are not encrypted. Use it for
non-sensitive test messages. The original upload's architecture and device
troubleshooting notes are preserved in `UPLOAD_README.md` as reference material.

## Code

- `lib/main.dart`: Material 3 chat interface.
- `lib/ble_chat_controller.dart`: BLE roles, lifecycle, receipts and persistence.
- `lib/ble_protocol.dart`: bounded JSON fragmentation and reassembly.
- `lib/chat_message.dart`: stored message model.
- `test/`: framing, controller and UI tests.

Generated Android scaffolding is included, so the app can be built directly
without running the setup scripts from the original ZIP.
